import React from "react";
import PickImage from "./screens/camera"

export default class App extends React.Component{
  render(){
    return(
      <PickImage/>
    )
  }
}